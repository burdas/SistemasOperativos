/////////////////////////////
//       fragmenta.h       //
/////////////////////////////

/*
 * Nombre: fragmenta.c
 * Autor: Marcos Burdaspar Celada
 * Descripción: Declaración de fragmenta() y borrarg()
 */

char **fragmenta(const char *cadena); 
void borrarg(char **arg);